﻿using System;

namespace Graph
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GraphMaker graphMaker = new GraphMaker();
            graphMaker.AddPoint(0);
            for (int i = 2; i <=6; i++)
            {
                graphMaker.AddPoint();
            }

            //fill graph by arcs
            graphMaker.AddExitArc(1, 2, 7);
            graphMaker.AddExitArc(1, 3, 9);
            graphMaker.AddExitArc(1, 6, 14);
            graphMaker.AddExitArc(2, 3, 10);
            graphMaker.AddExitArc(2, 4, 15);
            graphMaker.AddExitArc(3, 6, 2);
            graphMaker.AddExitArc(3, 4, 11);
            graphMaker.AddExitArc(4,5,6);
            graphMaker.AddExitArc(5,6,9);
            graphMaker.DrawGraph();

            Console.WriteLine();

            graphMaker.DeyxtraMethod();

            Console.WriteLine("Deyxtra solution");
            graphMaker.DrawGraph();
            Console.ReadKey();
        }
    }
}
